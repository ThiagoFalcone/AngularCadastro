import { Component } from '@angular/core';

@Component({
  selector: 'app-info-projeto',
  imports: [],
  templateUrl: './info-projeto.component.html',
  styleUrl: './info-projeto.component.css'
})
export class InfoProjetoComponent {

}
